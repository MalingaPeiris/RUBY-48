package Models;

public class Admin extends StaffMember {

    public Admin(String SID, String StaffName, String StaffAddress, long StaffPhone, String StaffEmail, String Username, String Password) {
        super(SID, StaffName, StaffAddress, StaffPhone, StaffEmail, Username, Password);
    }

}
