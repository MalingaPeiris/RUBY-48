package Models;

public class CampGroups {

    public String GroupID;
    public String InCharge;
    public String CampMembers;

    public CampGroups(String GroupID, String InCharge, String CampMembers) {
        this.GroupID = GroupID;
        this.InCharge = InCharge;
        this.CampMembers = CampMembers;
    }

}
