package Models;

public class Nurse extends StaffMember {

    public Nurse(String SID, String StaffName, String StaffAddress, long StaffPhone, String StaffEmail, String Username, String Password) {
        super(SID, StaffName, StaffAddress, StaffPhone, StaffEmail, Username, Password);
    }

}
